optimize table bayes_seen;
optimize table bayes_token;
optimize table bayes_vars;
show table status;
