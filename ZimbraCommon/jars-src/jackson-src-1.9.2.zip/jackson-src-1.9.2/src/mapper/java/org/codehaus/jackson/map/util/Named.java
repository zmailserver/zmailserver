package org.codehaus.jackson.map.util;

/**
 * Simple tag interface mostly to allow sorting by name
 *
 * @since 1.9
 */
public interface Named {
    public String getName();
}
